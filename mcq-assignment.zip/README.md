# Internship Assignment – Online MCQ System

## Objective
To develop a basic online MCQ system where users can:
- View MCQs
- Select answers
- Submit answers
- View score

## Tech Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Spring Boot (REST API)
- Database: MySQL

## Features
- Add/View MCQs (Admin)
- Attempt Quiz (User)
- Score Display

## How to Run
1. Import backend project into Spring Boot.
2. Import `database.sql` into MySQL.
3. Open `frontend/index.html` in browser.