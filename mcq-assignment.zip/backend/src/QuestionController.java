@RestController
@RequestMapping("/api/questions")
@CrossOrigin
public class QuestionController {
    @Autowired
    private QuestionRepository repo;

    @GetMapping
    public List<Question> getAll() {
        return repo.findAll();
    }

    @PostMapping("/submit")
    public int submitAnswers(@RequestBody List<UserAnswer> answers) {
        int score = 0;
        for (UserAnswer ans : answers) {
            Question q = repo.findById(ans.getId()).orElse(null);
            if (q != null && q.getCorrectOption().equalsIgnoreCase(ans.getAnswer())) {
                score++;
            }
        }
        return score;
    }
}