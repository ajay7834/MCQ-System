@Repository
public interface QuestionRepository extends JpaRepository<Question, Integer> { }