public class UserAnswer {
    private int id;
    private String answer;
    // Getters & Setters
}