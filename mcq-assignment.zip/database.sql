CREATE DATABASE mcq_system;
USE mcq_system;

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    option_a VARCHAR(255),
    option_b VARCHAR(255),
    option_c VARCHAR(255),
    option_d VARCHAR(255),
    correct_option CHAR(1)
);

INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option) VALUES
('What is the capital of India?', 'Delhi', 'Mumbai', 'Chennai', 'Kolkata', 'A'),
('Which language is used for Android development?', 'Swift', 'Java', 'PHP', 'Python', 'B'),
('What does HTTP stand for?', 'Hyper Type Text Protocol', 'HyperText Transfer Protocol', 'HighText Transfer Protocol', 'Hyper Transfer Text Process', 'B');