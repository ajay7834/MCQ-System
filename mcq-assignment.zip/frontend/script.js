let quizForm = document.getElementById("quizForm");
let answers = [];

fetch("http://localhost:8080/api/questions")
  .then(res => res.json())
  .then(data => {
    data.forEach((q, index) => {
      let html = `
        <div class="question">
          <p>${index + 1}. ${q.question}</p>
          <label><input type="radio" name="q${q.id}" value="A"> ${q.optionA}</label><br>
          <label><input type="radio" name="q${q.id}" value="B"> ${q.optionB}</label><br>
          <label><input type="radio" name="q${q.id}" value="C"> ${q.optionC}</label><br>
          <label><input type="radio" name="q${q.id}" value="D"> ${q.optionD}</label>
        </div>`;
      quizForm.innerHTML += html;
    });
  });

function submitQuiz() {
  answers = [];
  const inputs = document.querySelectorAll('input[type="radio"]:checked');
  inputs.forEach(input => {
    const id = parseInt(input.name.replace("q", ""));
    answers.push({ id: id, answer: input.value });
  });

  fetch("http://localhost:8080/api/questions/submit", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(answers)
  })
    .then(res => res.json())
    .then(score => {
      document.getElementById("result").innerText = "Your Score: " + score;
    });
}